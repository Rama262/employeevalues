import Input from './Empdata/Input.js'
function App() {
  return (
    <div>
     <Input/>
    </div>
  );
}

export default App;
